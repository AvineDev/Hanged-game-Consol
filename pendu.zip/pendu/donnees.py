"""fichier des donnes"""
#nombre d'essai
nb_coups=8

#fichier qui garde les scores 
nom_fichier_scores="score"
#nos mots 
liste_mots = [
"armoire",
"boucle",
"buisson",
"bureau",
"chaise",
"carton",
"couteau",
"fichier",
"garage",
"glace",
"journal",
"kiwi",
"lampe",
"liste",
"montagne",
"remise",
"sandale",
"taxi",
"vampire",
"volant",
]