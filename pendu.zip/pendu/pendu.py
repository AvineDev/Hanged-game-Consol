from donnees import *
from fonctions import *
#recuperation des scores de la partie

scores= recup_scores()

#prenom le userName

utilisateur=recup_nom_utilisateur()

#s'il est nouveau on l'ajoute

if utilisateur not in scores.keys():
    scores[utilisateur]=0

#une variable pour savoir quand arrêter la partie
continuer_partie='o'

while continuer_partie !='n':
    print("Joueur {} : {} point(s)".format(utilisateur,scores[utilisateur]))
    mot_a_trouver= choisier_mot()
    lettres_trouvees=[]
    mot_trouve= recup_mot_masque(mot_a_trouver,lettres_trouvees)
    nb_chances=nb_coups
    while mot_a_trouver != mot_trouve and nb_chances>0:
        print("Mot à trouver {} (encore {} chances)".format(mot_trouve,nb_chances))
        lettre=recup_lettre()
        if lettre in lettres_trouvees:
            print("Vous avez déjà choisi cette lettre")
        elif lettre in mot_a_trouver:
            lettres_trouvees.append(lettre)
            print("Bien joué Edjoor!")
        else:
            nb_chances -=1
            print("..Désolé, cette lettre ne se trouve pas dans le mot à trouver ")
        mot_trouve=recup_mot_masque(mot_a_trouver,lettres_trouvees)


    #le mot est trouvé ou le nombres d'essai est off

    if mot_a_trouver==mot_trouve:
        print("Félicitations, vous avez touver le mot {}".format(mot_a_trouver))
    else:
        print("Evoooor: Vous avez perdu!")
    #on modifie son score

    scores[utilisateur] +=nb_chances

    continuer_partie=input("Souhaitez vous continuer la partie?")
    continuer_partie=continuer_partie.lower()

enregistrer_scores(scores)

print("Partie terminée avec {} point(s): Top!".format(scores[utilisateur]))


            
